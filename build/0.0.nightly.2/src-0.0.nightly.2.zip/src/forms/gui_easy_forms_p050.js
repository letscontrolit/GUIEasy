/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P050 = {};
guiEasy.forms.plugin.P050.name = "";
guiEasy.forms.plugin.P050.category = "";
guiEasy.forms.plugin.P050.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P050.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

