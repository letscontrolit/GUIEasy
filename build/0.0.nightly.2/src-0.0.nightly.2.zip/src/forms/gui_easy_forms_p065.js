/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P065 = {};
guiEasy.forms.plugin.P065.name = "df player mini mp3";
guiEasy.forms.plugin.P065.category = "notify";
guiEasy.forms.plugin.P065.state = "testing"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P065.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

