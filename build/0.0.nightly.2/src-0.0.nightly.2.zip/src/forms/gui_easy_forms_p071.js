/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P071 = {};
guiEasy.forms.plugin.P071.name = "";
guiEasy.forms.plugin.P071.category = "";
guiEasy.forms.plugin.P071.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P071.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

