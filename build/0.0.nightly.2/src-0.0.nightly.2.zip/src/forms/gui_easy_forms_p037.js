/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P037 = {};
guiEasy.forms.plugin.P037.name = "mqtt import";
guiEasy.forms.plugin.P037.category = "generic";
guiEasy.forms.plugin.P037.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P037.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

