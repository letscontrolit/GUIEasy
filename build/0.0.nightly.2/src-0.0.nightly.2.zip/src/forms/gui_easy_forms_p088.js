/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P088 = {};
guiEasy.forms.plugin.P088.name = "ir heat pump";
guiEasy.forms.plugin.P088.category = "communication";
guiEasy.forms.plugin.P088.state = "testing"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P088.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

