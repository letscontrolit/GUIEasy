/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P020 = {};
guiEasy.forms.plugin.P020.name = "serial server";
guiEasy.forms.plugin.P020.category = "communication";
guiEasy.forms.plugin.P020.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P020.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

