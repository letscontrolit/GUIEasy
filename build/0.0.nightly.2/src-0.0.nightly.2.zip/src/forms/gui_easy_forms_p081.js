/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P081 = {};
guiEasy.forms.plugin.P081.name = "";
guiEasy.forms.plugin.P081.category = "";
guiEasy.forms.plugin.P081.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P081.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

