/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.notification.N002 = {};
guiEasy.forms.notification.N002.name = "buzzer";
guiEasy.forms.notification.N002.category = "internal";
guiEasy.forms.notification.N002.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.notification.N002.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

