/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P055 = {};
guiEasy.forms.plugin.P055.name = "";
guiEasy.forms.plugin.P055.category = "";
guiEasy.forms.plugin.P055.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P055.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

