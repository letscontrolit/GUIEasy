/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.controller.C003 = {};
guiEasy.forms.controller.C003.name = "nodo";
guiEasy.forms.controller.C003.category = "telnet";
guiEasy.forms.controller.C003.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.controller.C003.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

