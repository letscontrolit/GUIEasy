/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.controller.C016 = {};
guiEasy.forms.controller.C016.name = "cache control";
guiEasy.forms.controller.C016.category = "internal";
guiEasy.forms.controller.C016.state = "development"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.controller.C016.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

