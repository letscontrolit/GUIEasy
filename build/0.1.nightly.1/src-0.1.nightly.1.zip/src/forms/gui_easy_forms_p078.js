/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P078 = {};
guiEasy.forms.plugin.P078.name = "eastron smd120c/220t/230/630";
guiEasy.forms.plugin.P078.category = "energy (ac)";
guiEasy.forms.plugin.P078.state = "testing"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P078.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

