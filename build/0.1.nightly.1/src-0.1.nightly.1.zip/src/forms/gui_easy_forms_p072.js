/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P072 = {};
guiEasy.forms.plugin.P072.name = "hdc1080 (i2c)";
guiEasy.forms.plugin.P072.category = "environment";
guiEasy.forms.plugin.P072.state = "testing"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P072.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

