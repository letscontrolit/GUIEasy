/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.controller.C011 = {};
guiEasy.forms.controller.C011.name = "generic advanced";
guiEasy.forms.controller.C011.category = "http";
guiEasy.forms.controller.C011.state = "testing"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.controller.C011.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

