/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P089 = {};
guiEasy.forms.plugin.P089.name = "ping";
guiEasy.forms.plugin.P089.category = "communication";
guiEasy.forms.plugin.P089.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P089.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

