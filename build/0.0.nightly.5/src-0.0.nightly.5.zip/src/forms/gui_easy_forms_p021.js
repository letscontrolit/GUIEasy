/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P021 = {};
guiEasy.forms.plugin.P021.name = "level control";
guiEasy.forms.plugin.P021.category = "regulator";
guiEasy.forms.plugin.P021.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P021.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

