/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P068 = {};
guiEasy.forms.plugin.P068.name = "sht30/31/35";
guiEasy.forms.plugin.P068.category = "environment";
guiEasy.forms.plugin.P068.state = "testing"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P068.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

