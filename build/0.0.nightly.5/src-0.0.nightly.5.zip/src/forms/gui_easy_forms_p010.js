/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P010 = {};
guiEasy.forms.plugin.P010.name = "bh1750";
guiEasy.forms.plugin.P010.category = "light";
guiEasy.forms.plugin.P010.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P010.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

