/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P062 = {};
guiEasy.forms.plugin.P062.name = "mpr121 touch";
guiEasy.forms.plugin.P062.category = "keypad";
guiEasy.forms.plugin.P062.state = "testing"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P062.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

