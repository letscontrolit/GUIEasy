/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P053 = {};
guiEasy.forms.plugin.P053.name = "pmsx003";
guiEasy.forms.plugin.P053.category = "dust";
guiEasy.forms.plugin.P053.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P053.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

