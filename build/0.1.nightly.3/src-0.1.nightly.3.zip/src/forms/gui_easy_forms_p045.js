/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P045 = {};
guiEasy.forms.plugin.P045.name = "mpu6050";
guiEasy.forms.plugin.P045.category = "gyro";
guiEasy.forms.plugin.P045.state = "testing"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P045.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

