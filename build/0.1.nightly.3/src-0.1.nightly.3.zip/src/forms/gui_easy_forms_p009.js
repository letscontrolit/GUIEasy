/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P009 = {};
guiEasy.forms.plugin.P009.name = "mcp23017";
guiEasy.forms.plugin.P009.category = "switch input";
guiEasy.forms.plugin.P009.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P009.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

