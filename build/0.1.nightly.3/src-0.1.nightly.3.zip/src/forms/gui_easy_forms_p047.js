/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P047 = {};
guiEasy.forms.plugin.P047.name = "soil moisture sensor";
guiEasy.forms.plugin.P047.category = "environment";
guiEasy.forms.plugin.P047.state = "testing"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P047.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

