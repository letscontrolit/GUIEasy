/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P025 = {};
guiEasy.forms.plugin.P025.name = "ads1115";
guiEasy.forms.plugin.P025.category = "analog input";
guiEasy.forms.plugin.P025.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P025.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

