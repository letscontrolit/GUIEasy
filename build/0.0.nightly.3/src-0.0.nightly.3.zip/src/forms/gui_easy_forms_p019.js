/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P019 = {};
guiEasy.forms.plugin.P019.name = "pcf8574";
guiEasy.forms.plugin.P019.category = "switch input";
guiEasy.forms.plugin.P019.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P019.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

