/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P071 = {};
guiEasy.forms.plugin.P071.name = "kamstrup multical 401";
guiEasy.forms.plugin.P071.category = "communication";
guiEasy.forms.plugin.P071.state = "testing"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P071.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

