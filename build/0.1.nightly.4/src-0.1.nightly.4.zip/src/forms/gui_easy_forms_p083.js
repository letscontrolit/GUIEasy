/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P083 = {};
guiEasy.forms.plugin.P083.name = "sgp30";
guiEasy.forms.plugin.P083.category = "gases";
guiEasy.forms.plugin.P083.state = "testing"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P083.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

