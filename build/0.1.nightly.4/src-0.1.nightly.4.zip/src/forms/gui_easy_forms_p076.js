/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P076 = {};
guiEasy.forms.plugin.P076.name = "hlw8012/bl0937";
guiEasy.forms.plugin.P076.category = "energy (ac)";
guiEasy.forms.plugin.P076.state = "testing"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P076.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

