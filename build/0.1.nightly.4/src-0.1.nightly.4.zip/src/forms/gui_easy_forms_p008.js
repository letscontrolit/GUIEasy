/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P008 = {};
guiEasy.forms.plugin.P008.name = "wiegand";
guiEasy.forms.plugin.P008.category = "rfid";
guiEasy.forms.plugin.P008.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P008.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

