/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P003 = {};
guiEasy.forms.plugin.P003.name = "pulse counter";
guiEasy.forms.plugin.P003.category = "generic";
guiEasy.forms.plugin.P003.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P003.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

