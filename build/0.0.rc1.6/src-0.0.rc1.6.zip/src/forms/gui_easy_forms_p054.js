/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P054 = {};
guiEasy.forms.plugin.P054.name = "dmx512 tx";
guiEasy.forms.plugin.P054.category = "communication";
guiEasy.forms.plugin.P054.state = "testing"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P054.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

