/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P077 = {};
guiEasy.forms.plugin.P077.name = "cse7766 (pow r2)";
guiEasy.forms.plugin.P077.category = "energy (ac)";
guiEasy.forms.plugin.P077.state = "testing"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P077.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

