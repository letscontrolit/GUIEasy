/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P035 = {};
guiEasy.forms.plugin.P035.name = "ir transmitter";
guiEasy.forms.plugin.P035.category = "communication";
guiEasy.forms.plugin.P035.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P035.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

