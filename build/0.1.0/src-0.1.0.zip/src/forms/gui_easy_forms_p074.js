/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P074 = {};
guiEasy.forms.plugin.P074.name = "tsl2591";
guiEasy.forms.plugin.P074.category = "light";
guiEasy.forms.plugin.P074.state = "testing"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P074.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

