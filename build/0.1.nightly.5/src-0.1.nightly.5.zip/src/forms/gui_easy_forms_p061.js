/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P061 = {};
guiEasy.forms.plugin.P061.name = "pcf8574/mcp23017";
guiEasy.forms.plugin.P061.category = "keypad";
guiEasy.forms.plugin.P061.state = "testing"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P061.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

