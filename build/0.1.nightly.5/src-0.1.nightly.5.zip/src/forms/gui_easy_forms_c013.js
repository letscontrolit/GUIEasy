/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.controller.C013 = {};
guiEasy.forms.controller.C013.name = "esp easy p2p networking";
guiEasy.forms.controller.C013.category = "udp";
guiEasy.forms.controller.C013.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.controller.C013.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

