/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P001 = {};
guiEasy.forms.plugin.P001.name = "gpio";
guiEasy.forms.plugin.P001.category = "switch input";
guiEasy.forms.plugin.P001.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P001.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

