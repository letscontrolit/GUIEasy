/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P007 = {};
guiEasy.forms.plugin.P007.name = "pcf8591";
guiEasy.forms.plugin.P007.category = "analog input";
guiEasy.forms.plugin.P007.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P007.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

