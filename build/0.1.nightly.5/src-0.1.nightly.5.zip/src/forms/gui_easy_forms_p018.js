/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P018 = {};
guiEasy.forms.plugin.P018.name = "gp2y10";
guiEasy.forms.plugin.P018.category = "dust";
guiEasy.forms.plugin.P018.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P018.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

