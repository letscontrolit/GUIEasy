/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */
//syntax of curly... if you want to skip a setting set it to "
//TOGGLE--pathToSettings--uniqueID--label--true(1)Text|false(0)Text
//NUMBER--pathToSettings--uniqueID--label--defaultValue--minValue--maxValue--stepValue

guiEasy.forms.plugin.P002 = {};
guiEasy.forms.plugin.P002.name = "internal";
guiEasy.forms.plugin.P002.category = "analog input";
guiEasy.forms.plugin.P002.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P002.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
