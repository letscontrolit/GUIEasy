/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P066 = {};
guiEasy.forms.plugin.P066.name = "veml6040";
guiEasy.forms.plugin.P066.category = "light";
guiEasy.forms.plugin.P066.state = "testing"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P066.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

