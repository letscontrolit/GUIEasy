/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P011 = {};
guiEasy.forms.plugin.P011.name = "promini extender";
guiEasy.forms.plugin.P011.category = "extra io";
guiEasy.forms.plugin.P011.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P011.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

