/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P014 = {};
guiEasy.forms.plugin.P014.name = "si7021/htu21d";
guiEasy.forms.plugin.P014.category = "environment";
guiEasy.forms.plugin.P014.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P014.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

