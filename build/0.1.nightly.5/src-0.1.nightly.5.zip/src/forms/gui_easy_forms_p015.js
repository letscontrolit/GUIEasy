/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P015 = {};
guiEasy.forms.plugin.P015.name = "tsl2561";
guiEasy.forms.plugin.P015.category = "light";
guiEasy.forms.plugin.P015.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P015.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

