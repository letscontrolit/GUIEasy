/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P081 = {};
guiEasy.forms.plugin.P081.name = "cron";
guiEasy.forms.plugin.P081.category = "generic";
guiEasy.forms.plugin.P081.state = "testing"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P081.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

