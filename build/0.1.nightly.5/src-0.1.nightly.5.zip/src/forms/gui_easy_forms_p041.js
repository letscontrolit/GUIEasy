/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P041 = {};
guiEasy.forms.plugin.P041.name = "neo pixel word clock";
guiEasy.forms.plugin.P041.category = "output";
guiEasy.forms.plugin.P041.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P041.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

