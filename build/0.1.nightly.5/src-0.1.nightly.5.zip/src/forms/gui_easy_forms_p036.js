/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P036 = {};
guiEasy.forms.plugin.P036.name = "oled framed SSD1306/SH1106";
guiEasy.forms.plugin.P036.category = "display";
guiEasy.forms.plugin.P036.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P036.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

