/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P024 = {};
guiEasy.forms.plugin.P024.name = "mlx90614";
guiEasy.forms.plugin.P024.category = "environment";
guiEasy.forms.plugin.P024.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P024.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

