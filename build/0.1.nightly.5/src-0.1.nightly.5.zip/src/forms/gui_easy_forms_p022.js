/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P022 = {};
guiEasy.forms.plugin.P022.name = "pca9685";
guiEasy.forms.plugin.P022.category = "extra io";
guiEasy.forms.plugin.P022.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P022.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

