/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P056 = {};
guiEasy.forms.plugin.P056.name = "SDS011/018/198";
guiEasy.forms.plugin.P056.category = "dust";
guiEasy.forms.plugin.P056.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P056.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

