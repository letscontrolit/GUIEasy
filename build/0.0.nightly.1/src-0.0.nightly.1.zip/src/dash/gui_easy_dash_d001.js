/* GUIEasy  Copyright (C) 2019-2019  Jimmy "Grovkillen" Westberg */
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.dash.D001 = `
Add HTML or CURLY here...
`;  //--------------------------- HTML or CURLY -------------------------------//

guiEasy.dash.D001.name = "";
guiEasy.dash.D001.category = "";
guiEasy.dash.D001.state = ""; //normal, testing, development
