/* GUIEasy  Copyright (C) 2019-2019  Jimmy "Grovkillen" Westberg */

guiEasy.dash = function (number) {
    return guiEasy.dash["D" + ("000" + number).slice(-3)];
};