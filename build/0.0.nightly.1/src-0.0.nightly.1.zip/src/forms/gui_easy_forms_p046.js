/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P046 = {};
guiEasy.forms.plugin.P046.name = "";
guiEasy.forms.plugin.P046.category = "";
guiEasy.forms.plugin.P046.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P046.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

