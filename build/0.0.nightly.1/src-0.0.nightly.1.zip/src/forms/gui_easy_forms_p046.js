/* GUIEasy  Copyright (C) 2019  Jimmy "Grovkillen" Westberg */
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P046 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P046.name = "";
guiEasy.forms.plugin.P046.category = "";
guiEasy.forms.plugin.P046.state = "normal"; //normal, testing, development
