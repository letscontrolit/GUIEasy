/* GUIEasy  Copyright (C) 2019-2019  Jimmy "Grovkillen" Westberg */
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P074 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P074.name = "";
guiEasy.forms.plugin.P074.category = "";
guiEasy.forms.plugin.P074.state = "normal"; //normal, testing, development
