/* GUIEasy  Copyright (C) 2019  Jimmy "Grovkillen" Westberg */
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P004 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P004.name = "";
guiEasy.forms.plugin.P004.category = "";
guiEasy.forms.plugin.P004.state = "normal"; //normal, testing, development
