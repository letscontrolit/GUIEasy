/* GUIEasy  Copyright (C) 2019  Jimmy "Grovkillen" Westberg */
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P018 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P018.name = "";
guiEasy.forms.plugin.P018.category = "";
guiEasy.forms.plugin.P018.state = "normal"; //normal, testing, development
