/* GUIEasy  Copyright (C) 2019  Jimmy "Grovkillen" Westberg */
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.notification.N002 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.notification.N002.name = "";
guiEasy.forms.notification.N002.category = "";
guiEasy.forms.notification.N002.state = "normal"; //normal, testing, development