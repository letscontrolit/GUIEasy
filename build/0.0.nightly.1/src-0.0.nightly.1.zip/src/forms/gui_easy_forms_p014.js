//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P014 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P014.name = "";
guiEasy.forms.plugin.P014.category = "";
guiEasy.forms.plugin.P014.state = "normal"; //normal, testing, development
