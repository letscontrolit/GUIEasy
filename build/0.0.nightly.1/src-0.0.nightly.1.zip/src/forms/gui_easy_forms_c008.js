/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.controller.C008 = {};
guiEasy.forms.controller.C008.name = "";
guiEasy.forms.controller.C008.category = "";
guiEasy.forms.controller.C008.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.controller.C008.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

