/* GUIEasy  Copyright (C) 2019-2019  Jimmy "Grovkillen" Westberg */
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P081 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P081.name = "";
guiEasy.forms.plugin.P081.category = "";
guiEasy.forms.plugin.P081.state = "normal"; //normal, testing, development
