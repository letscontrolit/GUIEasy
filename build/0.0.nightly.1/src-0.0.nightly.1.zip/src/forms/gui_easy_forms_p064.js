/* GUIEasy  Copyright (C) 2019-2019  Jimmy "Grovkillen" Westberg */
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P064 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P064.name = "";
guiEasy.forms.plugin.P064.category = "";
guiEasy.forms.plugin.P064.state = "normal"; //normal, testing, development
