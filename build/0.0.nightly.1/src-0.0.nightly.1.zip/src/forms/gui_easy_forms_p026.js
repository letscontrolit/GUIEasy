/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P026 = {};
guiEasy.forms.plugin.P026.name = "system info";
guiEasy.forms.plugin.P026.category = "generic";
guiEasy.forms.plugin.P026.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P026.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

