/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.controller.C017 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.controller.C017.name = "";
guiEasy.forms.controller.C017.category = "";
guiEasy.forms.controller.C017.state = "normal"; //normal, testing, development
