/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P031 = {};
guiEasy.forms.plugin.P031.name = "";
guiEasy.forms.plugin.P031.category = "";
guiEasy.forms.plugin.P031.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P031.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

