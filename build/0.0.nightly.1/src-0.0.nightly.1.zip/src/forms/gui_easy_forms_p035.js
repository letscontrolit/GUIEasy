/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P035 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P035.name = "";
guiEasy.forms.plugin.P035.category = "";
guiEasy.forms.plugin.P035.state = "normal"; //normal, testing, development
