//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P054 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P054.name = "";
guiEasy.forms.plugin.P054.category = "";
guiEasy.forms.plugin.P054.state = "normal"; //normal, testing, development
