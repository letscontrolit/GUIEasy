/* GUIEasy  Copyright (C) 2019  Jimmy "Grovkillen" Westberg */
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.controller.C014 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.controller.C014.name = "";
guiEasy.forms.controller.C014.category = "";
guiEasy.forms.controller.C014.state = "normal"; //normal, testing, development
