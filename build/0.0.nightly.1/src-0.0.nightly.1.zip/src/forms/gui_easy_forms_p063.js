//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P063 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P063.name = "";
guiEasy.forms.plugin.P063.category = "";
guiEasy.forms.plugin.P063.state = "normal"; //normal, testing, development
