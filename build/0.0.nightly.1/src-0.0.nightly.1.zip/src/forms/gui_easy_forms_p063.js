/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P063 = {};
guiEasy.forms.plugin.P063.name = "";
guiEasy.forms.plugin.P063.category = "";
guiEasy.forms.plugin.P063.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P063.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

