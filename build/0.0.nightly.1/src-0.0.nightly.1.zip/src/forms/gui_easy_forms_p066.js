//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P066 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P066.name = "";
guiEasy.forms.plugin.P066.category = "";
guiEasy.forms.plugin.P066.state = "normal"; //normal, testing, development
