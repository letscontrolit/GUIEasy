//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P021 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P021.name = "";
guiEasy.forms.plugin.P021.category = "";
guiEasy.forms.plugin.P021.state = "normal"; //normal, testing, development
