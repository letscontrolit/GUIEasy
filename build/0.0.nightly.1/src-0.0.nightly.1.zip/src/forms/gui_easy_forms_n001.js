/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.notification.N001 = {};
guiEasy.forms.notification.N001.name = "";
guiEasy.forms.notification.N001.category = "";
guiEasy.forms.notification.N001.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.notification.N001.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

