//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.controller.C007 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.controller.C007.name = "";
guiEasy.forms.controller.C007.category = "";
guiEasy.forms.controller.C007.state = "normal"; //normal, testing, development
