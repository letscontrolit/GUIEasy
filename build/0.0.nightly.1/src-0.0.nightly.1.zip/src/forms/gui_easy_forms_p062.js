/* GUIEasy  Copyright (C) 2019-2019  Jimmy "Grovkillen" Westberg */
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P062 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P062.name = "";
guiEasy.forms.plugin.P062.category = "";
guiEasy.forms.plugin.P062.state = "normal"; //normal, testing, development
