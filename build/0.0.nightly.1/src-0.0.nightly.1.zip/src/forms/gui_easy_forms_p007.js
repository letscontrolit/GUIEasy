//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P007 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P007.name = "";
guiEasy.forms.plugin.P007.category = "";
guiEasy.forms.plugin.P007.state = "normal"; //normal, testing, development
