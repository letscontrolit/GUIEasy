/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P005 = {};
guiEasy.forms.plugin.P005.name = "DHT11/12/22  SONOFF2301/7021";
guiEasy.forms.plugin.P005.category = "environment";
guiEasy.forms.plugin.P005.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P005.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

