/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P012 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P012.name = "";
guiEasy.forms.plugin.P012.category = "";
guiEasy.forms.plugin.P012.state = "normal"; //normal, testing, development
