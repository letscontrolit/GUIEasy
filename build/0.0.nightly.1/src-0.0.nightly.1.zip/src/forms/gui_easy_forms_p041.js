//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P041 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P041.name = "";
guiEasy.forms.plugin.P041.category = "";
guiEasy.forms.plugin.P041.state = "normal"; //normal, testing, development
