/* GUIEasy  Copyright (C) 2019-2019  Jimmy "Grovkillen" Westberg */
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P028 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P028.name = "";
guiEasy.forms.plugin.P028.category = "";
guiEasy.forms.plugin.P028.state = "normal"; //normal, testing, development
