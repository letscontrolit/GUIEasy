/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.controller.C018 = {};
guiEasy.forms.controller.C018.name = "RN2483 / RN2903";
guiEasy.forms.controller.C018.category = "lora ttn";
guiEasy.forms.controller.C018.state = "development"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.controller.C018.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

