//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P048 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P048.name = "";
guiEasy.forms.plugin.P048.category = "";
guiEasy.forms.plugin.P048.state = "normal"; //normal, testing, development
