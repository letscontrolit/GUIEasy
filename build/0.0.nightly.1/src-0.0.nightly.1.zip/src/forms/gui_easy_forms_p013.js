/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P013 = {};
guiEasy.forms.plugin.P013.name = "HC-SR04, RCW-0001, etc.";
guiEasy.forms.plugin.P013.category = "position";
guiEasy.forms.plugin.P013.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P013.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

