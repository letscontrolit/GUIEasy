/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P060 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P060.name = "";
guiEasy.forms.plugin.P060.category = "";
guiEasy.forms.plugin.P060.state = "normal"; //normal, testing, development
