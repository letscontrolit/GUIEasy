/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.controller.C004 = {};
guiEasy.forms.controller.C004.name = "ThingSpeak";
guiEasy.forms.controller.C004.category = "http";
guiEasy.forms.controller.C004.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.controller.C004.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

