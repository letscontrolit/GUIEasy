//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P080 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P080.name = "";
guiEasy.forms.plugin.P080.category = "";
guiEasy.forms.plugin.P080.state = "normal"; //normal, testing, development
