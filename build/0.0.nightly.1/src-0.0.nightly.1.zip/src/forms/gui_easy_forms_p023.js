/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P023 = {};
guiEasy.forms.plugin.P023.name = "";
guiEasy.forms.plugin.P023.category = "";
guiEasy.forms.plugin.P023.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P023.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

