/* GUIEasy  Copyright (C) 2019  Jimmy "Grovkillen" Westberg */
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P027 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P027.name = "";
guiEasy.forms.plugin.P027.category = "";
guiEasy.forms.plugin.P027.state = "normal"; //normal, testing, development
