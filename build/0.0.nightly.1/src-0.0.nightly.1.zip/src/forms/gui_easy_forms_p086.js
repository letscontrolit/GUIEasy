//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P086 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P086.name = "";
guiEasy.forms.plugin.P086.category = "";
guiEasy.forms.plugin.P086.state = "normal"; //normal, testing, development
