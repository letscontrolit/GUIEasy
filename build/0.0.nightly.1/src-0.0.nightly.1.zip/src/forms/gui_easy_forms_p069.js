//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P069 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P069.name = "";
guiEasy.forms.plugin.P069.category = "";
guiEasy.forms.plugin.P069.state = "normal"; //normal, testing, development
