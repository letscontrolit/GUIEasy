/* GUIEasy  Copyright (C) 2019  Jimmy "Grovkillen" Westberg */
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P009 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P009.name = "";
guiEasy.forms.plugin.P009.category = "";
guiEasy.forms.plugin.P009.state = "normal"; //normal, testing, development
