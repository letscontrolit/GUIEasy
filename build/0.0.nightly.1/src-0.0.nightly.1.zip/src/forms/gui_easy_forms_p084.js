//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P084 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P084.name = "";
guiEasy.forms.plugin.P084.category = "";
guiEasy.forms.plugin.P084.state = "normal"; //normal, testing, development
