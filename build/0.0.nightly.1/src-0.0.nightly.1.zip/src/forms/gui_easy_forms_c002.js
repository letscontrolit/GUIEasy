/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.controller.C002 = {};
guiEasy.forms.controller.C002.name = "";
guiEasy.forms.controller.C002.category = "";
guiEasy.forms.controller.C002.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.controller.C002.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

