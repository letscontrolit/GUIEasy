//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.controller.C002 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
