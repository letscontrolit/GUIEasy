//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P059 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P059.name = "";
guiEasy.forms.plugin.P059.category = "";
guiEasy.forms.plugin.P059.state = "normal"; //normal, testing, development
