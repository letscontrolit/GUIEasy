/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P059 = {};
guiEasy.forms.plugin.P059.name = "";
guiEasy.forms.plugin.P059.category = "";
guiEasy.forms.plugin.P059.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P059.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

