/* GUIEasy  Copyright (C) 2019  Jimmy "Grovkillen" Westberg */
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.controller.C011 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.controller.C011.name = "";
guiEasy.forms.controller.C011.category = "";
guiEasy.forms.controller.C011.state = "normal"; //normal, testing, development
