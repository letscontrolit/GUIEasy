//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.controller.C005 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.controller.C005.name = "";
guiEasy.forms.controller.C005.category = "";
guiEasy.forms.controller.C005.state = "normal"; //normal, testing, development
