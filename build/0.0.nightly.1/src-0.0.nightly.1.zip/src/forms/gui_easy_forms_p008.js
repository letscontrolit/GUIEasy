//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P008 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P008.name = "";
guiEasy.forms.plugin.P008.category = "";
guiEasy.forms.plugin.P008.state = "normal"; //normal, testing, development
