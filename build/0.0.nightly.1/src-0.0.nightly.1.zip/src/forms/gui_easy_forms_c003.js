/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.controller.C003 = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.controller.C003.name = "";
guiEasy.forms.controller.C003.category = "";
guiEasy.forms.controller.C003.state = "normal"; //normal, testing, development
