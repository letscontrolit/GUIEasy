/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P027 = {};
guiEasy.forms.plugin.P027.name = "ina219";
guiEasy.forms.plugin.P027.category = "energy (dc)";
guiEasy.forms.plugin.P027.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P027.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

