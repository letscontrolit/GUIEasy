/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P051 = {};
guiEasy.forms.plugin.P051.name = "am2320";
guiEasy.forms.plugin.P051.category = "environment";
guiEasy.forms.plugin.P051.state = "testing"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P051.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

