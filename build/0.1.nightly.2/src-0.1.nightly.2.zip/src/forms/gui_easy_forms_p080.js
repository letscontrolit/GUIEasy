/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P080 = {};
guiEasy.forms.plugin.P080.name = "ibutton";
guiEasy.forms.plugin.P080.category = "switch input";
guiEasy.forms.plugin.P080.state = "testing"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P080.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

