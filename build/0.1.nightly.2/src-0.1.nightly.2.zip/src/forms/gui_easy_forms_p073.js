/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P073 = {};
guiEasy.forms.plugin.P073.name = "7-segment display";
guiEasy.forms.plugin.P073.category = "display";
guiEasy.forms.plugin.P073.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P073.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

