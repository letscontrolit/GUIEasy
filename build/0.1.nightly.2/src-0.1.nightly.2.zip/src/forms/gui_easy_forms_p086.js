/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P086 = {};
guiEasy.forms.plugin.P086.name = "homie receiver";
guiEasy.forms.plugin.P086.category = "generic";
guiEasy.forms.plugin.P086.state = "testing"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P086.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

