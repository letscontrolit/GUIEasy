/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P055 = {};
guiEasy.forms.plugin.P055.name = "chiming";
guiEasy.forms.plugin.P055.category = "notify";
guiEasy.forms.plugin.P055.state = "testing"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P055.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

