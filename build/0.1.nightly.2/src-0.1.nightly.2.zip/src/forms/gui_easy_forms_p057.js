/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P057 = {};
guiEasy.forms.plugin.P057.name = "ht16k33";
guiEasy.forms.plugin.P057.category = "display";
guiEasy.forms.plugin.P057.state = "testing"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P057.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

