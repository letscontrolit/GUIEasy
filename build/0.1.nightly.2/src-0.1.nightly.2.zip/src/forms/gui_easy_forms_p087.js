/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P087 = {};
guiEasy.forms.plugin.P087.name = "serial proxy";
guiEasy.forms.plugin.P087.category = "communication";
guiEasy.forms.plugin.P087.state = "testing"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P087.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

