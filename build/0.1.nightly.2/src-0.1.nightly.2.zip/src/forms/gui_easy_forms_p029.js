/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P029 = {};
guiEasy.forms.plugin.P029.name = "domoticz mqtt helper";
guiEasy.forms.plugin.P029.category = "output";
guiEasy.forms.plugin.P029.state = "normal"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P029.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

