/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P064 = {};
guiEasy.forms.plugin.P064.name = "apds9960";
guiEasy.forms.plugin.P064.category = "gesture";
guiEasy.forms.plugin.P064.state = "development"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P064.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

