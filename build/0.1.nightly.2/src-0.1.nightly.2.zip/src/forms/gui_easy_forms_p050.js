/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P050 = {};
guiEasy.forms.plugin.P050.name = "tcs34725";
guiEasy.forms.plugin.P050.category = "light";
guiEasy.forms.plugin.P050.state = "development"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P050.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

