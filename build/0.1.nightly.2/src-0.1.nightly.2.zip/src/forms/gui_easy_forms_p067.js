/* GUIEasy  Copyright (C) 2019-2020  Jimmy "Grovkillen" Westberg */

guiEasy.forms.plugin.P067 = {};
guiEasy.forms.plugin.P067.name = "hx711 load cell";
guiEasy.forms.plugin.P067.category = "weight";
guiEasy.forms.plugin.P067.state = "testing"; //normal, testing, development
//------------------------------- HTML or CURLY -------------------------------//
guiEasy.forms.plugin.P067.html = `
Add html or curly syntax here...
`;  //--------------------------- HTML or CURLY -------------------------------//

